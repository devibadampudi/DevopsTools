# Azure IoT Hub Provisioning Service SDKs for Node.js code samples

The `Samples` folder contains single sample files both for devices and service applications using the Azure IoT Hub Provisioning Service.