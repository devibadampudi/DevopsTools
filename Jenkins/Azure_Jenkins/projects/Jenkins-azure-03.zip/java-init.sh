#!/bin/sh
echo "-------------------------------------------------Update the packages-------------------------------------------------"
sudo apt-get update -y

echo "-------------------------------------------------First install Java-------------------------------------------------"
sudo apt-get install openjdk-8-jre-headless -y
