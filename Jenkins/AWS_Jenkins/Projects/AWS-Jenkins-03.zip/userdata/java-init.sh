#!/bin/sh

# firewall installation
sudo apt-get update
sudo apt-get install -y firewalld
sudo firewall-cmd --zone=public --add-port=8080/tcp --permanent
sudo firewall-cmd --reload

echo "-------------------------------------------------Update the packages-------------------------------------------------"
sudo apt-get update -y

echo "-------------------------------------------------First install Java-------------------------------------------------"
sudo apt-get install openjdk-8-jre-headless -y